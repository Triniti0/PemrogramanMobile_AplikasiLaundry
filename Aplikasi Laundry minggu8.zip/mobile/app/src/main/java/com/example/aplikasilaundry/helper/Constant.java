package com.example.aplikasilaundry.helper;

public class Constant {
    public static final String ID = "id";
}
